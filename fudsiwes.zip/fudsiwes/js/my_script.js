function sendID(value)
{   
    if(window.XMLHttpRequest)
    {
		xmlhttp = new XMLHttpRequest();
	}else
	{
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");  
	}
	xmlhttp.onreadystatechange = function()
	{
		
		if(xmlhttp.readyState==4 && xmlhttp.status==200){
		
			document.getElementById("lga").innerHTML = xmlhttp.responseText;
		}
		else{
			document.getElementById("lga").innerHTML ="<img src='../src/loading.gif'> Pls. wait...."; 
		
		}
	}
	//alert(accid);
	xmlhttp.open("GET","local_govt.php?state_id="+value,true);
	xmlhttp.send();
}
