<?php
include_once 'connection.php';
include_once 'fetch.php';
?>
<!DOCTYPE html>
<html>
<head>


<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/logoo.jpg">

    <title>Gamji Grand Concept Nigeria Limited</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/docs.min.css" rel="stylesheet">
    <script src="assets/js/ie-emulation-modes-warning.js"></script>
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    <link rel="stylesheet" type="text/css" href="adorn/scroll.css">
    <link href="adorn/carousel.css" rel="stylesheet">
</head>
<body  style="background-color:transparent; background-image:url('img/bg.jpg')">

    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Gamji Grand Concept Nigeria Limited</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="index.html">Home</a></li>
            <li><a href="panell.php">Menu</a></li>
            <li><a><button onclick="window.print();">Print Page</button></a></li>  
          </ul>
          <!--<form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Search...">
          </form>-->
        </div>
      </div>
    </div>

<br><br><br><br>


<div class="container">
    <h2 class="h2">Customer Enquiry List</h2>
<div class="table-responsive">
<?php
error_reporting(0);
$con = mysql_connect("localhost" ,"root" , "");
mysql_select_db("gamjigrand" , $con);

displayimage();

function displayimage()
{
//$con = mysql_connect("localhost" ,"root" , "");
//mysql_select_db("gamjigrand", $con);

$page = $_GET['page'];

if($page == "" || $page == "1"){
   $page1 = 0;
}
else{
$page1 = ($page * 10) - 10;
}



$qry = mysql_query("SELECT * FROM enquiries LIMIT $page1,10");

echo "<table  class='table'>";
echo "<tr class='tr' >";
        print "<th>";  echo "SNO"; print "</th>";		
				print "<th>"; echo "Name"; print "</th>";
				print "<th>";echo"E-Mail"; print "</th>";
				print "<th>"; echo "Phone"; print "</th>";
				print "<th>";echo"Enquiry Type"; print "</th>";
				print "<th>";echo"Message"; print "</th>";
                print "<th>";echo"Action"; print "</th>";		
        print "</tr>";
        $c = 1;
while($res = mysql_fetch_array($qry))
{
  echo"<tr class='trb'>";
        print "<td>"; echo $c; print "</td>";
				print "<td>"; echo $res['fullname']; print "</td>";
				print "<td>"; echo $res['email']; print "</td>";
				print "<td>"; echo $res['phoneno']; print "</td>";
				print "<td>"; echo $res['enquiry']; print "</td>";
				print "<td>"; echo $res['message']; print "</td>";
                print "<td>"; ?> <a href="customer_home.php?delete=<?php echo $res['id'];  ?>&catego=<?php echo $res['Enroll_No'];?>" class='btn btn-danger' >Delete</a><?php print "</td>";				
        echo "</tr>";
        $c++;
}
echo"</table>";

mysql_close($con);
}



//$con = mysql_connect("localhost" ,"root" , "");
//mysql_select_db("gamjigrand" , $con);
$sql = mysql_query("SELECT * FROM enquiries");
$num = mysql_num_rows($sql);

$a = $num/10;
$a = ceil($a);

echo "<br>";

?>

<ul class="pagination"> 
<li><a href="#">&laquo;</a></li>
<?php
for ($b=1; $b<=$a; $b++) { 
    ?>    <li><a href="customer_home.php?page=<?php echo $b; ?>"><?php echo $b; ?> </a> </li> <?php
}
?>
<li><a href="#">&raquo;</a></li>
</ul>


</div>
</div>

    <script src="js/jquery.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
    <script src="assets/js/docs.min.js"></script>
</body>
</html>