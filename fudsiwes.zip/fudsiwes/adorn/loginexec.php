<?php
session_start();
require_once('connection.php');
mysql_select_db("gamjigrand");      
        $uname = $_POST['username'];
        $pwd = $_POST['password'];

        $check = "SELECT * FROM account WHERE userName='$uname' AND Password='$pwd' ";
        $check2 = mysql_query($check) or die(mysql_error());
        $exist = mysql_num_rows($check2);
        if($exist != '0'){	
            $row = mysql_fetch_assoc($check2);
            
             header('LOCATION: customer_home.php');
            }else{
                    $_SESSION['ad_err'] = 'ERROR: Unable to login. Contact Super Admin';
                    header('LOCATION: customer_login.php');
            }
        }else{
                $_SESSION['ad_err'] =  'Invalid Username and Password Combination';
                header('LOCATION: customer_login.php');
        }
?>