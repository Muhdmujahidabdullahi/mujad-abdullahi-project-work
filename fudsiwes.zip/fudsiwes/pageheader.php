
<nav class="navbar navbar-default custom-header">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button><a class="navbar-brand navbar-link" href="#" id="head">FUD<span> E-Siwes System</span> </a></div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav links">
                    <li role="presentation"><a href="#">Home </a></li>
                    <li role="presentation"><a href="supervisor_login.php">Staff/Supervisors </a></li>
                    <li role="presentation"><a href="login.php"> Students</a></li>
                    <li role="presentation"><a href="#"> About Us</a></li>
                    <li role="presentation"><a href="#"> Contact Us</a></li>
                    <li role="presentation"><a href="#" class="custom-navbar"> FAQ's<span class="badge">new</span></a></li>
                    <li role="presentation"><a href="industrysupervisorlogin.php"> Industry Base/Supervisor</a></li>
                </ul>
                <!--<ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#"> <span class="caret"></span><img src="assets/img/avatar.jpg" class="dropdown-image"></a>
                        <ul class="dropdown-menu dropdown-menu-right" role="menu">
                            <li><a href="#">Settings </a></li>
                            <li><a href="#">Payments </a></li>
                            <li class="active"><a href="#">Logout </a></li>
                        </ul>
                    </li>
                </ul>-->
            </div>
        </div>
    </nav>