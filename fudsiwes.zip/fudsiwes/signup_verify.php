

<?php 

error_reporting(0);
session_start();

 ?>
 <!DOCTYPE html>
 <html>
 <head>
    <title>FUD Siwes System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/docs.min.css" rel="stylesheet">
    <script src="assets/js/ie-emulation-modes-warning.js"></script>
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    <link rel="stylesheet" type="text/css" href="adorn/scroll.css">
    <link href="adorn/carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/user.css">
    <link rel="stylesheet" href="adorn/user.css">
    <link rel="stylesheet" href="adorn/logincss.css">
</head>
<body>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog"
aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">

	<div class="modal-content">
<div class="modal-header">
<button type="button" class="close"
data-dismiss="modal" aria-hidden="true">
&times;
</button>
<h4 class="modal-title" id="myModalLabel">
Login Page
</h4>
</div>
<div class="modal-body">


                     <?php
                     if ($_SESSION['ad_err']<> "") {
                     ?>
                     <div class="alert alert-dismissable alert-<?php echo"danger"; ?>" >
                     <button data-dismiss="alert" class="close" type="button">x</button>
                     <?php

                        if(isset( $_SESSION['ad_err']) && strlen( $_SESSION['ad_err']) > 0){
                         echo $_SESSION['ad_err'];
                          $_SESSION['ad_err'] = "";
                          }
                      ?></div><?php
                    }

                    

                   ?>




<div class="login-card"> 

         <form class="form-signin"  method="POST"><span class="reauth-email"> </span>

            <?php 

          $reg = $_GET['id'];
          //echo $id;
          //echo "string";
           //$reg = 'SCI/COM/00001';
          if ($_POST) {
            $pass = $_POST['pass1'];
            require_once('connection.php');
            $run=$dbfound->QUERY("INSERT INTO login_account_details (Stu_reg_no , Password) VALUES('$reg','$pass')");
            if ($run) {
                
                //$_SESSION['ad_err'] =  'Success Account Set! Click Here to Login into Your Account';
                $_SESSION['ad_err'] = '<div class="alert alert-success">' .' <a href="login.php" class="alert-link">' .'Success! Click Here to Login into Your Account'.'</a>'.'</div>';
                header('LOCATION: password_create.php');
            }
            else{
              
                $_SESSION['ad_err'] =  'Something Went Wrong!! Plesae Try Again Latter';
                header('LOCATION: password_create.php');
            }
          }
        ?>


            <input class="form-control" type="password" required name="pass1" placeholder="Select Your Password" autofocus="" >
            <input class="form-control" type="password" required name="pass2" placeholder="Confirm Password" id="inputPassword">
          
            <button class="btn btn-primary btn-block btn-lg btn-signin" type="submit" >Create</button>
        
        
    </div>




</div>
<div class="modal-footer">
<button type="button" class="btn btn-default"
data-dismiss="modal">Close
</button>
<button type="button" class="btn btn-primary" name="create">
Submit changes
</button>
</div>
</div><!-- /.modal-content -->
</form>
</div><!-- /.modal -->
</div>

</body>
</html>