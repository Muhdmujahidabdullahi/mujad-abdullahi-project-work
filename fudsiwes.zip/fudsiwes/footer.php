
<footer>
        <div class="row">
            <div class="col-md-4 col-sm-6 footer-navigation">
                <h3><a href="#">FUD<span>Nigeria </span></a></h3>
                <p class="links"><a href="#">Home</a><strong> · </strong><a href="#">Departments</a><strong> · </strong><a href="#">Student</a><strong> · </strong><a href="#">About</a><strong> · </strong><a href="#">Contact</a></p>
                <p class="company-name"> Copyright &copy; <a href="#">Federal University Dutse</a>. All Rights Reserved
                Design by <a target="_blank" href="yaro2k@yahoo.com">Mujahid Minjibir</a></p>
            </div>
            <div class="col-md-4 col-sm-6 footer-contacts">
                <div><span class="fa fa-map-marker footer-contacts-icon"> </span>
                    <p><span class="new-line-span">Federal University</span> Jigawa, Nigeria</p>
                </div>
                <div><span class="fa fa-phone footer-contacts-icon"></span>
                    <p class="footer-center-info email text-left"> +234(0) 00990000</p>
                </div>
                <div><span class="fa fa-envelope footer-contacts-icon"></span>
                    <p> <a href="#" target="_blank">support@fud.edu.ng</a></p>
                </div>
            </div>
            <div class="clearfix visible-sm-block"></div>
            <div class="col-md-4 footer-about">
                <h4>About the Siwes</h4>
                <p>Students’ Industrial Work Experience Scheme (SIWES) is a programme designed to expose and prepare students of Universities, Polytechnics, Colleges of Technology, Colleges of Agriculture and Education
                </p>
                <div class="social-links social-icons"><a href="#"><span class="fa fa-facebook"></span></a><a href="#"><span class="fa fa-twitter"></span></a><a href="#"><span class="fa fa-linkedin"></span></a><a href="#"><span class="fa fa-github"></span></a></div>
            </div>
        </div>
    </footer>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    